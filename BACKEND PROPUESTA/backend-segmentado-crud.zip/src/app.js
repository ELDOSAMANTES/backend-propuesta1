import express from 'express';
import cors from 'cors';
import morgan from 'morgan';
import { config } from './config/config.js';
import routes from './routes/index.js';
import { connectDB } from './libs/sequelize.js';

const app = express();

app.use(cors());
app.use(morgan('dev'));
app.use(express.json({ limit: '5mb' }));

app.use('/api/v1', routes);

// Manejo de errores
// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  console.error(err);
  res.status(400).json({
    message: err.message ?? 'Error',
    stack: process.env.NODE_ENV === 'development' ? err.stack : undefined,
  });
});

async function bootstrap() {
  await connectDB();
  app.listen(config.port, () => {
    console.log(`🚀 Server running at http://localhost:${config.port}`);
  });
}

bootstrap();
